from cloudshell.workflow.orchestration.sandbox import Sandbox
from cloudshell.orch.training.teardown_orchestrator import TrainingTeardownWorkflow

sandbox = Sandbox()

TrainingTeardownWorkflow(sandbox).register()

sandbox.execute_teardown()
