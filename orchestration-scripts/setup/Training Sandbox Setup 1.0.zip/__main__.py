from cloudshell.workflow.orchestration.sandbox import Sandbox
from cloudshell.orch.training.setup_orchestrator import TrainingSetupWorkflow

sandbox = Sandbox()

workflow = TrainingSetupWorkflow(sandbox)
workflow.register()
workflow.initialize()

sandbox.execute_setup()
